import React, { useEffect } from 'react';
import { ExposedDropdownMenu, TextField } from '@episerver/ui-framework';
// NETCORE
// How import CriteriaEditorProps ts interface? It is located in \netcore\CMSUI\EPiServer.VisitorGroups.Management.UI\clientResources\src\Models
// import { CriteriaEditorProps } from '../../../clientResources/src/Models/CriteriaEditorProps';
// const CustomerProperties = (props: CriteriaEditorProps) => {

const CustomerProperties = (props: any) => {

    const [localModelState, setLocalModelState] = React.useState({});

    useEffect(() => {
        let state = { ...props.settings };
        setLocalModelState(state);
    }, []);

    const emitValueChange = (newState: any) => {
        props.onValueChange(newState);
        setLocalModelState(newState);
    }

    const getTwoDigits = (value: number) => value < 10 ? `0${value}` : value;

    const formattedDateString = (dateString: string) => {
        let date = dateString && dateString != '' ? new Date(dateString) : new Date();
        return date.getFullYear() + "-" + getTwoDigits(date.getMonth() + 1) + "-" + getTwoDigits(date.getDate());
    }

    return (
        <>
            <ExposedDropdownMenu
                outlined
                options={props && props.editorConfig.propertyName.selectItems.map(item => {
                    return {
                        label: item.text,
                        value: item.value.toString()
                    }
                })}
                label={props && props.editorConfig.propertyName.label}
                value={localModelState.propertyName?.toString()}
                onValueChange={value => {
                    let newState = {...localModelState};
                    newState.propertyName = value;

                    // The change requires us to reset the other inputs
                    newState.fromDate = '';
                    newState.toDate = '';
                    newState.customerGroup = '';
                    newState.registrationSource = '';
                    newState.country = '';
                    newState.region = '';
                    newState.addressPostalCode = '';  
                    newState.state = '';

                    emitValueChange(newState);
                }}
            />


            {localModelState?.propertyName === "birthdate" &&  
            <>
                <TextField
                    style={{ marginLeft: '6px', marginRight: '6px' }}
                    outlined
                    type="date"
                    defaultValue={formattedDateString(localModelState.fromDate)}
                    required
                    onChange={evt => {
                        let newState = { ...localModelState };
                        newState.fromDate = evt.currentTarget.value;
                        emitValueChange(newState);
                    }}
                />
                <TextField
                    style={{ marginLeft: '6px', marginRight: '6px' }}
                    outlined
                    type="date"
                    defaultValue={formattedDateString(localModelState.toDate)}
                    required
                    onChange={evt => {
                        let newState = { ...localModelState };
                        newState.toDate = evt.currentTarget.value;
                        emitValueChange(newState);
                    }}
                />
            </>
            }

 
            {localModelState?.propertyName === "customergroup" &&  
            <span style={{marginLeft: '6px'}}>
                <ExposedDropdownMenu
                    outlined
                    options={props && props.editorConfig.customerGroup.selectItems.map(item => {
                        return {
                            label: item.text,
                            value: item.value.toString()
                        }
                    })}
                    required
                    label={props && props.editorConfig.customerGroup.label}
                    value={localModelState.customerGroup?.toString()}
                    onValueChange={value => {
                        let newState = { ...localModelState };
                        newState.customerGroup = value;
                        emitValueChange(newState);
                    }}
                />
            </span>
            }


            {localModelState?.propertyName === "registrationsource" &&  
            <>
            <TextField
                style={{ marginLeft: '6px', marginRight: '6px' }}
                outlined
                defaultValue={localModelState.registrationSource}
                required
                onChange={evt => {
                    let newState = { ...localModelState };
                    newState.registrationSource = evt.currentTarget.value;
                    emitValueChange(newState);
                }}
            />
            </>
            } 

            {localModelState?.propertyName === "country" &&  
            <span style={{marginLeft: '6px'}}>
                <ExposedDropdownMenu
                    outlined
                    options={props && props.editorConfig.country.selectItems.map(item => {
                        return {
                            label: item.text,
                            value: item.value.toString()
                        }
                    })}
                    required
                    label={props && props.editorConfig.country.label}
                    value={localModelState.country?.toString()}
                    onValueChange={value => {
                        let newState = { ...localModelState };
                        newState.country = value;
                        emitValueChange(newState);
                    }}
                />
            </span>
            }

            {localModelState?.propertyName === "region" &&  
            <>
            <TextField
                style={{ marginLeft: '6px', marginRight: '6px' }}
                outlined
                defaultValue={localModelState.region}
                required
                onChange={evt => {
                    let newState = { ...localModelState };
                    newState.region = evt.currentTarget.value;
                    emitValueChange(newState);
                }}
            />
            </>
            } 

            {localModelState?.propertyName === "addresspostalcode" &&  
            <>
            <TextField
                style={{ marginLeft: '6px', marginRight: '6px' }}
                outlined
                defaultValue={localModelState.addressPostalCode}
                required
                onChange={evt => {
                    let newState = { ...localModelState };
                    newState.addressPostalCode = evt.currentTarget.value;
                    emitValueChange(newState);
                }}
            />
            </>
            } 

            {localModelState?.propertyName === "state" &&  
            <span style={{marginLeft: '6px'}}>
                <ExposedDropdownMenu
                    outlined
                    options={props && props.editorConfig.state.selectItems.map(item => {
                        return {
                            label: item.text,
                            value: item.value.toString()
                        }
                    })}
                    required
                    label={props && props.editorConfig.state.label}
                    value={localModelState.state?.toString()}
                    onValueChange={value => {
                        let newState = { ...localModelState };
                        newState.state = value;
                        emitValueChange(newState);
                    }}
                />
            </span>
            }


            
        </>
    )
}

export default CustomerProperties