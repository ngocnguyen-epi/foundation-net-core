//>>built
define("epi-addon-tinymce/tinymce-loader",["tinymce/tinymce.min"],function(){window.tinymce.overrideDefaults({base_url:require.toUrl("tinymce"),suffix:".min"});return window.tinymce;});