require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/CategoryRelationEditor.html':"﻿<div class=\"epi-linkeditcollectionediteditor\">\r\n    <h1 data-dojo-attach-point=\"titleNode\"></h1>\r\n    <h2 class=\"primaryCategory-container__heading\">${resources.primarycategory.title}</h2>\r\n    <div class=\"primaryCategory-container\">\r\n        <div data-dojo-attach-point=\"primaryCategoryMissingNode\" class=\"dgrid-no-data\"></div>\r\n        <div class=\"primaryCategory-container__list\">\r\n            <div data-dojo-attach-point=\"primaryCategoryNameNode\" class=\"primaryCategory__name epi-iconObjectCategory\"></div>\r\n            <div data-dojo-attach-point=\"primaryCategoryPathNode\" class=\"primaryCategory__path epi-ecf-uiPathLink clickablePath\"></div>\r\n        </div>\r\n    </div>\r\n    <div class=\"additionalCategories-container\">\r\n        <h2 class=\"additionalCategories-container__heading\">${resources.additionalcategories}</h2>\r\n        <div data-dojo-attach-point=\"collectionList\"></div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/CategoryCollectionEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/dom",
    "dojo/when",
    "dojo/topic",

    // dgrid
    "dgrid/OnDemandGrid",
    "dgrid/extensions/ColumnResizer",
    "dgrid/extensions/ColumnReorder",

    // EPi Framework
    "epi/shell/DestroyableByKey",
    "epi/shell/dgrid/Formatter",
    "epi/shell/widget/_FocusableMixin",

    // epi cms
    "epi-cms/dgrid/WithContextMenu",

    // ecf-ui
    "./_RelationCollectionEditorBase",
    "../viewmodel/CategoryCollectionEditorModel",
    "./LinkEditEditor",
    "../ModelSupport",
    "../../dgrid/_ClickablePathColumnMixin",

    // Resources
    "dojo/text!./templates/CategoryRelationEditor.html",
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.categorycollectioneditor"
],
    function (
        //dojo
        declare,
        dom,
        when,
        topic,

        //dgrid
        OnDemandGrid,
        ColumnResizer,
        ColumnReorder,

        // Epi Framework
        DestroyableByKey,
        Formatter,
        _FocusableMixin,

        // epi cms
        WithContextMenu,

        // ecf-ui
        _RelationCollectionEditorBase,
        CategoryCollectionEditorModel,
        LinkEditEditor,
        ModelSupport,
        _ClickablePathColumnMixin,

        // Resources
        template,
        resources
    ) {
        var collectionEditor = declare([_RelationCollectionEditorBase, _FocusableMixin], {
            // module:
            //      epi-ecf-ui/contentediting/editors/CategoryCollectionEditor
            // summary:
            //      Represents the editor widget for the categories of an entry or category.

            gridSettings: { dndDisabled: true },

            modelType: CategoryCollectionEditorModel,

            gridType: declare([OnDemandGrid, Formatter, ColumnResizer, ColumnReorder, _ClickablePathColumnMixin, WithContextMenu]),

            allowedDndTypes: [ModelSupport.contentTypeIdentifier.nodeContent, ModelSupport.linkTypeIdentifier.relation],

            itemEditorTypes: [ModelSupport.contentTypeIdentifier.nodeContent],

            resources: resources,

            relationType: ModelSupport.relationType.node,

            _addItem: function (item) {
                // The base implementation requires a dndSource property on the grid. Override to call model.addItem
                // without that requirement, we know the item is dragged from an external source.
                when(this._dndGetItemData(item), function (itemData) {
                    if (itemData) {
                        return this.model.addItem(itemData);
                    }
                }.bind(this));
            }
        });

        return declare([LinkEditEditor, DestroyableByKey], {

            resources: resources,

            templateString: template,

            gridCollectionType: collectionEditor,

            _setPrimaryCategoryNameAttr: { node: "primaryCategoryNameNode", type: "innerHTML" },

            _setPrimaryCategoryPathAttr: { node: "primaryCategoryPathNode", type: "innerHTML" },

            _setPrimaryCategoryMissingAttr: { node: "primaryCategoryMissingNode", type: "innerHTML" },

            _setTitleAttr: { node: "titleNode", type: "innerHTML" },

            buildRendering: function () {
                this.inherited(arguments);

                this.own(
                    this.gridCollection.model.watch("primaryCategory", function (property, oldValue, newValue) {
                        if (newValue) {
                            this.set("primaryCategoryName", newValue.name);
                            this.set("primaryCategoryPath", newValue.path);
                            this.set("primaryCategoryMissing", "");                            
                        } else {
                            this.set("primaryCategoryName", "");
                            this.set("primaryCategoryPath", "");
                            this.set("primaryCategoryMissing", resources.primarycategory.noprimarycategorymessage);
                        }
                    }.bind(this)),
                    this.gridCollection.model.watch("contentContext", function (property, oldValue, newValue) {
                        this.set("contentContext", newValue);
                    }.bind(this)));
            },

            postCreate: function () {
                this.inherited(arguments);
                this.set("title", resources.title);
                this.ownByKey("pathClick", this.on(".clickablePath:click", function (event) {
                    var contentLink = this.gridCollection.model.primaryCategory.target;
                    topic.publish("/epi/shell/context/request", { uri: "epi.cms.contentdata:///" + contentLink }, { sender: this });
                }.bind(this)));
            }
        });
    });