require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/GridWithDropContainer.html':"﻿<div class=\"epi-grid--with-container\">\r\n    <div class=\"push-padding--bottom\" data-dojo-attach-point=\"commandTargetNode\"></div>\r\n    <div class=\"epi-editor-overlay\" data-dojo-attach-point=\"overlayDnd\">\r\n        <div data-dojo-attach-point=\"gridNode\"></div>\r\n        <div data-dojo-attach-point=\"dropContainer\" class=\"epi-content-area-actionscontainer\"></div>\r\n    </div>\r\n</div>\r\n"}});
﻿define("epi-ecf-ui/contentediting/editors/_GridWithDropContainerMixin", [
    "dojo/_base/declare",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/topic",
    "epi/shell/dnd/Target",
    "epi-cms/contentediting/editors/_TextWithActionLinksMixin",
    "./LinkEditorDndMixin",
    "dojo/text!./templates/GridWithDropContainer.html"
], function(
    declare,
    aspect,
    domClass,
    domStyle,
    topic,
    Target,
    _TextWithActionLinksMixin,
    LinkEditorDndMixin,
    template
){
    return declare([_TextWithActionLinksMixin, LinkEditorDndMixin], {

        templateString: template,

        gridOverlayClass: "epi-grid-dnd-overlay",

        resources: null,

        buildRendering: function () {
            this.inherited(arguments);
            if (this.readOnly){
                domStyle.set(this.dropContainer, "display", "none");
            } else {
                this.setupActionLinks(this.dropContainer);
            }
            var dndTarget = new Target(this.dropContainer, {
                accept: this.allowedDndTypes,
                insertNodes: function () { }
            });

            this.own(dndTarget,
                    aspect.after(dndTarget, "onDropData", function (dndData, source, nodes, copy) {
                        this.onDndDrop(dndData, source, nodes, copy);
            }.bind(this), true));

            this.setupDndActions(dndTarget, "checkAcceptance");
        },

        getTemplateString: function () {
            // summary:
            //      The template string for drop area
            // tags:
            //      protected

            return {
                templateString: this.resources.drophere,
                actions: this.resources.actions
            };
        },

        executeAction: function (actionName) {
            // summary:
            //      Called when [entries] link clicked
            // tags:
            //      public override

            topic.publish("/epi/layout/pinnable/tools/toggle", true);
        },

        _setupDnD: function () {
            // summary:
            //      Set up the dnd on the grid.
            // tags:
            //      private
            this.inherited(arguments);
            var dndSource = this.grid.dndSource;
            this.setupDndActions(dndSource, "checkAcceptance");
            this.own(aspect.after(dndSource, "onDndStart", function (source, nodes, copy) {
                var accepted = dndSource.accept && dndSource.checkAcceptance(source, nodes);
                if (accepted) {
                    domClass.add(this.overlayDnd, this.gridOverlayClass);
                    domClass.remove(this.dropContainer, this.gridOverlayClass);
                } else {
                    domClass.remove(this.overlayDnd, this.gridOverlayClass);
                }
            }.bind(this), true));
        },

        _setupGrid: function(){
            this.inherited(arguments);
            this.styleGrid();
        },

        styleGrid: function(){
            this._setGridHeaderFont();
        },

        _setGridHeaderFont: function(){
            domClass.add(this.gridNode, "epi-plain-grid--small-header-font");
        }
    });
});