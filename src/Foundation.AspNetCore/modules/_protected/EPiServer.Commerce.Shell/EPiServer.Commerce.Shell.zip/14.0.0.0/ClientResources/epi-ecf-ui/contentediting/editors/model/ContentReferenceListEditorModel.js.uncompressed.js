﻿define("epi-ecf-ui/contentediting/editors/model/ContentReferenceListEditorModel", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",

    // epi-cms
    "epi-cms/component/command/ChangeContext",
    "epi-cms/contentediting/editors/model/ContentReferenceListEditorModel",
    "epi-cms/contentediting/ContentActionSupport",

    // epi-ecf-ui
    "../../../command/NavigateToEditPage"
],
function (
    //dojo
    array,
    declare,

    // epi-cms
    ChangeContextCommand,
    BaseContentReferenceListEditorModel,
    ContentActionSupport,

    // epi-ecf-ui
    NavigateToEditPageCommand
) {
    return declare([BaseContentReferenceListEditorModel], {
        // summary:
        //      Represents the Content reference list editor model in Commerce, which handles the Change context command as opening
        //      the content edit in Edit mode.

        navigateOnEdit: true,

        _navigateToEditPageCommand: null,

        postscript: function () {
            // summary:
            //      Mix constructor arguments into the object after construction.
            // tags:
            //      protected

            this._navigateToEditPageCommand = new NavigateToEditPageCommand({
                category: "menuWithSeparator"
            });
            this.inherited(arguments);

            if (this.get("navigateOnEdit")) {
                array.some(this.commands, function (command, index) {
                    if (command.isInstanceOf(ChangeContextCommand)) {
                        this.commands[index] = this._navigateToEditPageCommand;
                        return true;
                    }
                    return false;
                }, this);
            }
        },

        navigateToItem: function (item) {
            // summary:
            //      Navigate to the item edit page.
            // tags:
            //      public

            if (!this.get("navigateOnEdit")) {
                this.inherited(arguments);
                return;
            }

            if (!ContentActionSupport.hasAccess(item.accessMask, ContentActionSupport.accessLevel.Read)) {
                return;
            }
            this._navigateToEditPageCommand.execute();
        }
    });
});